<?php

/*
|--------------------------------------------------------------------------
| SMTP configuration
|--------------------------------------------------------------------------
| In this example, i'm using a default Zoho Mail configuration
*/
$config['protocol'] = 'smtp';
$config['smtp_host'] = "smtp.googlemail.com";
$config['smtp_port'] = 465;
$config['smtp_user'] = "uchihaferoza22@gmail.com";
$config['smtp_pass'] = 'jbnrokpjpjeiqzxt';
$config['charset'] = "iso-8859-1";
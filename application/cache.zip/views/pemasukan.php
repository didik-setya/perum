<div class="row">
    <div class="col-lg-6">

        <table class="table table-bordered">
            <tr>
                <th></th>
            </tr>
        </table>

    </div>
</div>